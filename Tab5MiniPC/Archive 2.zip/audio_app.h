// audio_app.h - which app is using the audio hardware, the shared volume, and the volume
// row (- button, slider, + button, percentage).
//
// THE ONE-AUDIO-APP RULE
// On the Tab5 the two microphones (ES7210) and the speaker (ES8388 + amp)
// share one I2S bus (I2S port 0, same clock pins). M5Unified can drive the
// bus as a microphone OR as a speaker, never both at once. The internet radio
// also plays through M5.Speaker. So at any moment exactly one of these uses
// the audio hardware:
//     nobody  |  Mic  |  Speaker  |  Radio
// Before an app starts its audio it calls audioStartMic() or
// audioStartSpeaker(). Both first call audioRelease(), which cleanly stops
// whoever had the hardware before. Every app's Exit() calls audioRelease().
//
// (This file is not called audio.h on purpose: Windows and macOS ignore
// upper/lower case in file names, so the radio library's <Audio.h> would
// find our file instead of its own.)
#pragma once
#include "ui.h"

enum AudioApp { AUDIO_NONE, AUDIO_MIC, AUDIO_SPEAKER, AUDIO_RADIO };
AudioApp audioApp = AUDIO_NONE;  // the app currently using the mic/speaker

void radioStopStream();  // defined in app_radio.h

// ---------------------------------------------------------------------------
// Volume: one setting shared by every screen that makes sound
// ---------------------------------------------------------------------------
int volumePercent = 80;

// Extra digital gain for the Tab5 speaker. M5Unified uses 4 on the Tab5,
// which is quiet on the small speaker; 8 doubles the level (+6 dB). Very loud
// radio streams may distort near 100 % with higher values.
constexpr uint8_t SPEAKER_BOOST = 8;

// Call once in setup(), while the speaker is stopped.
void audioBegin() {
  auto cfg = M5.Speaker.config();
  cfg.magnification = SPEAKER_BOOST;
  M5.Speaker.config(cfg);
}

// M5.Speaker multiplies the sound by (master volume)^2, so 50 % on a plain
// 0..255 scale would only give 25 % of the level. Taking the square root
// makes the slider percentage match the loudness: 50 % = half as loud.
void applyVolume() {
  M5.Speaker.setVolume((uint8_t)lroundf(255.0f * sqrtf(volumePercent / 100.0f)));
}

// ---------------------------------------------------------------------------
// Starting and stopping audio
// ---------------------------------------------------------------------------
void audioRelease() {
  switch (audioApp) {
    case AUDIO_MIC:
      M5.Mic.end();  // stops recording and frees the I2S bus
      break;
    case AUDIO_RADIO:
      radioStopStream();  // stop downloading/decoding first...
      [[fallthrough]];    // ...then stop the speaker as well
    case AUDIO_SPEAKER:
      M5.Speaker.stop();
      M5.Speaker.end();  // mutes the amp and frees the I2S bus
      break;
    case AUDIO_NONE:
      break;
  }
  audioApp = AUDIO_NONE;
}

bool audioStartMic() {
  if (audioApp == AUDIO_MIC) return true;
  audioRelease();
  if (!M5.Mic.begin()) return false;
  audioApp = AUDIO_MIC;
  return true;
}

// who = AUDIO_SPEAKER for sounds made by the sketch, AUDIO_RADIO for the radio.
bool audioStartSpeaker(AudioApp who = AUDIO_SPEAKER) {
  applyVolume();  // always start at the shared volume, whichever app set it
  if (audioApp == who) return true;
  audioRelease();
  if (!M5.Speaker.begin()) return false;
  applyVolume();
  audioApp = who;
  return true;
}

// ---------------------------------------------------------------------------
// Volume row
// ---------------------------------------------------------------------------
// The volume row is the slider row from ui.h, tied to volumePercent.
SliderRow volumeRow(int x, int y, int w, int btn, uint16_t bg) {
  return {x, y, w, btn, bg, "Volume", &volumePercent, 0};
}

void volumeRowDraw(const SliderRow& r) { sliderRowDraw(r); }

// Call every loop; applies the new volume when the slider moved.
bool volumeRowUpdate(const SliderRow& r) {
  if (!sliderRowUpdate(r)) return false;
  applyVolume();
  return true;
}
