// clock.h - everything about the date and time.
//
// How time works on the ESP32:
//   * The chip keeps one system clock in UTC (seconds since 1970).
//   * The TZ setting (time zone) turns UTC into local time whenever we call
//     localtime_r(). Changing the offset therefore changes the displayed time
//     instantly, without touching the clock itself.
//   * The system clock is lost on power-off. The Tab5 also has a battery-backed
//     RTC chip (RX8130). We keep UTC in it, so the time survives a reboot.
//     The RTC is a clock, not storage.
//
// Ways the time gets set:
//   1. at boot, from the RTC (if it holds a sensible date)
//   2. from the internet (NTP), automatically after Wi-Fi connects or via the
//      "Sync from internet" button on the Date & Time screen
//   3. by hand, on the Date & Time screen
#pragma once
#include <time.h>
#include <sys/time.h>
#include <esp_sntp.h>
#include <WiFi.h>
#include "ui.h"

// Default offset from UTC in minutes: +5:30 = India Standard Time (IST).
// The offset can be changed on the Date & Time screen (kept in RAM only,
// so it returns to this default after a reboot).
constexpr int DEFAULT_UTC_OFFSET_MIN = 5 * 60 + 30;
int utcOffsetMin = DEFAULT_UTC_OFFSET_MIN;

enum TimeSource { TIME_NOT_SET, TIME_FROM_RTC, TIME_FROM_INTERNET, TIME_BY_HAND };
TimeSource timeSource = TIME_NOT_SET;

// NTP state: the SNTP client runs in the background and calls ntpCallback()
// from its own task. That callback only sets a flag; clockLoop() (running
// in the main loop) then does the slower work like writing the RTC.
volatile bool ntpJustSynced = false;
bool ntpWaiting = false;          // a sync was started and has not answered yet
uint32_t ntpStartMs = 0;
time_t lastSyncTime = 0;          // when the last successful sync happened

// ---------------------------------------------------------------------------
// Time zone
// ---------------------------------------------------------------------------
// Builds a POSIX TZ string such as "LOC-5:30". POSIX counts the offset the
// other way round (west is positive), so UTC+5:30 is written as -5:30.
String tzString() {
  int m = -utcOffsetMin;
  char buf[24];
  snprintf(buf, sizeof(buf), "LOC%c%d:%02d", m < 0 ? '-' : '+', abs(m) / 60, abs(m) % 60);
  return String(buf);
}

void applyTimeZone() {
  setenv("TZ", tzString().c_str(), 1);
  tzset();
}

// "+05:30" style text for the current offset.
String offsetText() {
  char buf[24];
  snprintf(buf, sizeof(buf), "%c%02d:%02d", utcOffsetMin < 0 ? '-' : '+', abs(utcOffsetMin) / 60,
           abs(utcOffsetMin) % 60);
  return String(buf);
}

// Change the offset by a number of minutes (the screen uses 15-minute steps,
// which covers every real time zone, e.g. Nepal +5:45).
void changeUtcOffset(int deltaMin) {
  utcOffsetMin = constrain(utcOffsetMin + deltaMin, -12 * 60, 14 * 60);
  applyTimeZone();
}

// ---------------------------------------------------------------------------
// Reading the time
// ---------------------------------------------------------------------------
// Before anything sets the clock it starts in 1970, so any year before 2024
// means "not set yet".
bool timeIsValid() {
  return time(nullptr) > 1704067200;  // 2024-01-01 00:00 UTC
}

void localNow(struct tm& t) {
  time_t now = time(nullptr);
  localtime_r(&now, &t);
}

// "HH:MM" for the status bar, or "--:--" while the clock is not set.
void formatClock(char* buf, size_t len) {
  if (!timeIsValid()) {
    snprintf(buf, len, "--:--");
    return;
  }
  struct tm t;
  localNow(t);
  snprintf(buf, len, "%02d:%02d", t.tm_hour, t.tm_min);
}

// ---------------------------------------------------------------------------
// RTC (battery-backed clock chip), always kept in UTC
// ---------------------------------------------------------------------------
void saveTimeToRtc() {
  if (!M5.Rtc.isEnabled()) return;
  time_t now = time(nullptr);
  struct tm utc;
  gmtime_r(&now, &utc);
  M5.Rtc.setDateTime(&utc);
}

void loadTimeFromRtc() {
  if (!M5.Rtc.isEnabled()) return;
  M5.Rtc.setSystemTimeFromRtc();  // M5Unified reads the RTC as UTC
  applyTimeZone();                // (it touches TZ internally; set ours again)
  if (timeIsValid()) timeSource = TIME_FROM_RTC;
}

// ---------------------------------------------------------------------------
// Internet time (NTP)
// ---------------------------------------------------------------------------
void ntpCallback(struct timeval* tv) {
  (void)tv;
  ntpJustSynced = true;  // handled in clockLoop()
}

// Start (or restart) NTP. Needs Wi-Fi. The answer usually arrives within a
// second or two; clockLoop() notices it.
void startClockSync() {
  sntp_set_time_sync_notification_cb(ntpCallback);
  configTzTime(tzString().c_str(), "pool.ntp.org", "time.google.com");
  ntpWaiting = true;
  ntpStartMs = millis();
}

// ---------------------------------------------------------------------------
// Setting the time by hand
// ---------------------------------------------------------------------------
// Takes a LOCAL date and time (in the current offset). mktime() converts
// local time to UTC using our TZ setting.
void setTimeByHand(int year, int month, int day, int hour, int minute) {
  struct tm t = {};
  t.tm_year = year - 1900;
  t.tm_mon = month - 1;
  t.tm_mday = day;
  t.tm_hour = hour;
  t.tm_min = minute;
  t.tm_isdst = 0;
  struct timeval tv = {mktime(&t), 0};
  settimeofday(&tv, nullptr);

  // Stop NTP, otherwise its next hourly sync would overwrite the manual time.
  esp_sntp_stop();
  ntpWaiting = false;

  timeSource = TIME_BY_HAND;
  saveTimeToRtc();
}

// ---------------------------------------------------------------------------
// Called from setup() and every loop()
// ---------------------------------------------------------------------------
void clockBegin() {
  applyTimeZone();
  loadTimeFromRtc();
}

void clockLoop() {
  // Whenever Wi-Fi comes up (first connect or a reconnect), fetch the time.
  static bool wasOnline = false;
  static uint32_t lastCheckMs = 0;
  if (millis() - lastCheckMs >= 500) {
    lastCheckMs = millis();
    bool online = (WiFi.status() == WL_CONNECTED);
    if (online && !wasOnline) startClockSync();
    wasOnline = online;
  }

  if (ntpJustSynced) {
    ntpJustSynced = false;
    ntpWaiting = false;
    timeSource = TIME_FROM_INTERNET;
    lastSyncTime = time(nullptr);
    saveTimeToRtc();
    Serial.println("Clock: synced from the internet");
  }
  // Give up waiting after 15 s (the SNTP client keeps retrying quietly).
  if (ntpWaiting && millis() - ntpStartMs > 15000) ntpWaiting = false;
}
