// Tab5 Mini PC - a touchscreen home screen with six small apps for the
// M5Stack Tab5 (ESP32-P4). Each app shows off one piece of built-in hardware:
// camera, microphones, speaker and Wi-Fi.
//
// How the sketch is organised:
//   ui.h            colours, fonts, Button, header, icons (shared by all screens)
//   audio_app.h     which app uses the mic/speaker, shared volume + slider
//   clock.h         time zone offset, internet time (NTP), RTC
//   keyboard.h      on-screen keyboard (Wi-Fi password, stream URL)
//   app_home.h      Home screen: status bar + app tiles
//   app_*.h         one tab per screen, each with Enter / Loop / Exit functions
//   Tab5MiniPC.ino  (this file) setup(), loop() and the screen state machine
//
// Board: "M5Tab5" from the "esp32 by Espressif Systems" package (3.3.11+).
// See README.md for the exact settings.

#include <M5Unified.h>
#include "ui.h"
#include "audio_app.h"
#include "clock.h"
#include "keyboard.h"
#include "app_home.h"
#include "app_camera.h"
#include "app_recorder.h"
#include "app_micmeter.h"
#include "app_speaker.h"
#include "app_radio.h"
#include "app_addstream.h"
#include "app_wifi.h"
#include "app_datetime.h"

// ---------------------------------------------------------------------------
// Screen state machine
// ---------------------------------------------------------------------------
// Exactly one screen is active. Every screen has three functions:
//   Enter() - draw the whole screen once and start any hardware it needs
//   Loop()  - called over and over: handle touches, update what changed
//   Exit()  - stop and release that hardware before another screen starts
Screen currentScreen = HOME;
Screen requestedScreen = HOME;
bool switchRequested = false;

void goTo(Screen next) {
  requestedScreen = next;
  switchRequested = true;
}

void screenEnter(Screen s) {
  switch (s) {
    case HOME:      homeEnter();      break;
    case CAMERA:    cameraEnter();    break;
    case RECORDER:  recorderEnter();  break;
    case MICMETER:  micMeterEnter();  break;
    case SPEAKER:   speakerEnter();   break;
    case RADIO:     radioEnter();     break;
    case ADDSTREAM: addStreamEnter(); break;
    case WIFI:      wifiEnter();      break;
    case DATETIME:  dateTimeEnter();  break;
  }
}

void screenLoop(Screen s) {
  switch (s) {
    case HOME:      homeLoop();      break;
    case CAMERA:    cameraLoop();    break;
    case RECORDER:  recorderLoop();  break;
    case MICMETER:  micMeterLoop();  break;
    case SPEAKER:   speakerLoop();   break;
    case RADIO:     radioLoop();     break;
    case ADDSTREAM: addStreamLoop(); break;
    case WIFI:      wifiLoop();      break;
    case DATETIME:  dateTimeLoop();  break;
  }
}

void screenExit(Screen s) {
  switch (s) {
    case HOME:      homeExit();      break;
    case CAMERA:    cameraExit();    break;
    case RECORDER:  recorderExit();  break;
    case MICMETER:  micMeterExit();  break;
    case SPEAKER:   speakerExit();   break;
    case RADIO:     radioExit();     break;
    case ADDSTREAM: addStreamExit(); break;
    case WIFI:      wifiExit();      break;
    case DATETIME:  dateTimeExit();  break;
  }
}

// ---------------------------------------------------------------------------
// Arduino entry points
// ---------------------------------------------------------------------------
void setup() {
  auto cfg = M5.config();
  cfg.serial_baudrate = 115200;
  M5.begin(cfg);  // display, touch, power, RTC, IO expanders, audio codecs

  M5.Display.setRotation(SCREEN_ROTATION);
  Serial.printf("Tab5 Mini PC: display %d x %d\n", (int)M5.Display.width(), (int)M5.Display.height());

  // Start with the audio hardware free (see the one-audio-app rule in audio_app.h).
  M5.Speaker.end();
  M5.Mic.end();
  applyVolume();

  clockBegin();  // time zone + time from the RTC, if it has one

  screenEnter(currentScreen);
}

void loop() {
  M5.update();  // reads the touch panel (and buttons, power state)

  // Switch screens here, between two Loop() calls, so an app never gets
  // torn down while its own Loop() is still running.
  if (switchRequested) {
    switchRequested = false;
    screenExit(currentScreen);
    currentScreen = requestedScreen;
    screenEnter(currentScreen);
  }

  screenLoop(currentScreen);
  clockLoop();  // internet time sync bookkeeping (runs on every screen)

  // Give other tasks (Wi-Fi, audio) a moment to run. 1 ms keeps the UI and
  // the radio responsive while stopping loop() from hogging the CPU.
  delay(1);
}
