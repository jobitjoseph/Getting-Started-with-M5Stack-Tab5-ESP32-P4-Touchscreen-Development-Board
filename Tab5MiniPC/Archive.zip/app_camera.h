// app_camera.h - live preview from the built-in 2 MP camera, with Snap
// (freeze the current frame) and Resume.
//
// HOW A CAMERA FRAME REACHES THE SCREEN
//   1. The SC2356 sensor sends raw 1280 x 720 frames over MIPI-CSI.
//      It needs a 24 MHz clock, which we make with the LEDC PWM on GPIO 36.
//   2. ESP_Video (built into the Arduino core 3.3.11+) runs them through the
//      P4's ISP (image signal processor), which turns them into RGB565 and
//      does auto exposure / white balance.
//   3. The P4's PPA (pixel processing accelerator) crops the centre of the
//      16:9 frame to 4:3, scales it down to 768 x 576 and mirrors it, all in
//      hardware, straight into an M5Canvas buffer.
//   4. We draw the LIVE badge onto that canvas and push it to the display in
//      one go, so the badge never flickers.
// Snap simply stops step 1-4 from running, so the last frame stays on screen.
// Nothing is saved.
#pragma once

// ESP_Video ships with the Espressif core 3.3.11 and newer. The M5Stack board
// package (which also has a board called "M5Tab5") does not include it yet.
#if ESP_ARDUINO_VERSION < ESP_ARDUINO_VERSION_VAL(3, 3, 11)
#error "Please select Tools > Board > esp32 > M5Tab5 (package 'esp32 by Espressif Systems' 3.3.11 or newer). The M5Stack board package has no camera library (ESP_Video)."
#endif

#include <ESP_Video.h>
#include <driver/ppa.h>
#include <driver/i2c_master.h>
#include <esp_heap_caps.h>
#include "ui.h"

// Sensor output and on-screen preview size
constexpr int CAM_W = 1280, CAM_H = 720;
constexpr int PREVIEW_W = 768, PREVIEW_H = 576;
constexpr int PREVIEW_X = 32, PREVIEW_Y = HEADER_H + 28;

// Crop + scale: the PPA scales in steps of 1/16, so we use 13/16 (0.8125).
// 944 x 708 pixels from the middle of the frame become 767 x 575, which
// fills the 768 x 576 preview (the last pixel row/column stays black).
constexpr float CAM_SCALE = 13.0f / 16.0f;
constexpr int CROP_W = 944, CROP_H = 708;

// Change these if your preview is mirrored or upside down.
constexpr bool CAM_MIRROR_X = true;   // front camera: mirror like a selfie
constexpr bool CAM_MIRROR_Y = false;

constexpr int CAM_XCLK_PIN = 36;      // 24 MHz clock for the sensor
constexpr int CAM_BUFFERS = 2;        // frames the driver can fill ahead

ESPVideoClass camVideo;
ESPVideoCaptureDevClass camCapture;
ppa_client_handle_t camPpa = nullptr;
uint16_t* camPixels = nullptr;        // preview pixels (PSRAM, cache-aligned for the PPA)
size_t camPixelsSize = 0;
M5Canvas camCanvas(&M5.Display);      // wraps camPixels so we can draw on it

bool camRunning = false;
bool camFrozen = false;
uint32_t camFrames = 0, camFpsMs = 0;

// Right-hand controls
Button camSnapBtn = {950, 220, 180, 180, "Snap", C_AMBER, C_BG};
Button camResumeBtn = {890, 428, 300, 72, "Resume live", C_PANEL, C_TEXT};

// ---------------------------------------------------------------------------
// Drawing helpers
// ---------------------------------------------------------------------------
// The "LIVE" / "FROZEN" pill in the top-left corner of the preview.
void drawCamBadge() {
  auto& c = camCanvas;
  const char* text = camFrozen ? "FROZEN" : "LIVE";
  c.setFont(FONT_MONO);
  int w = 14 + 12 + 8 + c.textWidth(text) + 14;
  c.fillSmoothRoundRect(18, 18, w, 36, 18, C_PANEL);
  c.fillSmoothCircle(18 + 14 + 6, 36, 6, camFrozen ? C_BLUE : C_AMBER);
  c.setTextColor(C_TEXT);
  c.setTextDatum(middle_left);
  c.drawString(text, 18 + 14 + 12 + 8, 37);
}

void drawSnapButton() {
  auto& d = M5.Display;
  int cx = camSnapBtn.x + 90, cy = camSnapBtn.y + 90;
  d.fillSmoothCircle(cx, cy, 90, lgfx::color565(0x3a, 0x2a, 0x12));  // dark amber ring
  d.fillSmoothCircle(cx, cy, 84, camRunning ? C_AMBER : C_BORDER2);
  iconCamera(cx - 20, cy - 44, 40, C_BG, camRunning ? C_AMBER : C_BORDER2);
  d.setFont(FONT_TITLE);
  d.setTextColor(C_BG);
  d.setTextDatum(middle_center);
  d.drawString("Snap", cx, cy + 22);
}

// Message inside the preview frame (used when the camera fails to start).
void drawCamMessage(const char* line1, const char* line2) {
  auto& d = M5.Display;
  d.fillRect(PREVIEW_X, PREVIEW_Y + PREVIEW_H / 2 - 60, PREVIEW_W, 120, C_DARK);
  d.setTextDatum(middle_center);
  d.setFont(FONT_TITLE);
  d.setTextColor(C_TEXT2);
  d.drawString(line1, PREVIEW_X + PREVIEW_W / 2, PREVIEW_Y + PREVIEW_H / 2 - 20);
  d.setFont(FONT_SMALL);
  d.drawString(line2, PREVIEW_X + PREVIEW_W / 2, PREVIEW_Y + PREVIEW_H / 2 + 24);
}

// ---------------------------------------------------------------------------
// Start / stop
// ---------------------------------------------------------------------------
// Returns nullptr on success, or a short reason for the failure.
const char* cameraStart() {
  // 1) 24 MHz clock on GPIO 36 (1-bit PWM at 50 % duty = a square wave).
  if (!ledcAttach(CAM_XCLK_PIN, 24000000, 1)) return "could not start the 24 MHz clock";
  ledcWrite(CAM_XCLK_PIN, 1);
  delay(10);

  // 2) The sensor's control bus (SCCB) is the Tab5's internal I2C bus, which
  //    M5Unified already opened on I2C port 1. We reuse that bus instead of
  //    opening a second driver on the same pins.
  i2c_master_bus_handle_t bus = nullptr;
  if (i2c_master_get_bus_handle(I2C_NUM_1, &bus) != ESP_OK || !bus) return "internal I2C bus not found";

  ESPVideoCamConfigClass camConfig;
  camConfig.begin(bus);
  ESPVideoCSIConfigClass csiConfig;
  // dont_init_ldo = true: the display (MIPI-DSI) already powers the shared
  // MIPI PHY supply, so the camera must not configure it again.
  csiConfig.begin(camConfig, true);
  if (!camVideo.begin(csiConfig)) return "sensor not detected";

  if (!camCapture.begin(ESP_VIDEO_MIPI_CSI_DEVICE_NAME, CAM_BUFFERS)) return "could not open /dev/video0";
  if (!camCapture.setFormat(ESP_VIDEO_FORMAT_RGB565)) return "RGB565 not supported";
  if (!camCapture.startCapture()) return "could not start streaming";

  // 3) Output buffer for the PPA. It writes with DMA, so the buffer must be
  //    aligned to the cache line and its size a multiple of it (64 bytes
  //    covers the P4's L1 and L2 caches).
  camPixelsSize = (PREVIEW_W * PREVIEW_H * 2 + 63) & ~63;
  camPixels = (uint16_t*)heap_caps_aligned_calloc(64, 1, camPixelsSize, MALLOC_CAP_SPIRAM);
  if (!camPixels) return "not enough PSRAM";
  camCanvas.setColorDepth(16);
  camCanvas.setBuffer(camPixels, PREVIEW_W, PREVIEW_H, 16);

  ppa_client_config_t ppaConfig = {};
  ppaConfig.oper_type = PPA_OPERATION_SRM;  // SRM = scale, rotate, mirror
  if (ppa_register_client(&ppaConfig, &camPpa) != ESP_OK) return "PPA not available";

  camRunning = true;
  camFpsMs = millis();
  camFrames = 0;
  Serial.printf("Camera: streaming %lu x %lu\n", (unsigned long)camCapture.getWidth(),
                (unsigned long)camCapture.getHeight());
  return nullptr;
}

void cameraStop() {
  if (camCapture.isCaptureStarted()) camCapture.stopCapture();
  camCapture.end();
  camVideo.end();
  if (camPpa) {
    ppa_unregister_client(camPpa);
    camPpa = nullptr;
  }
  camCanvas.deleteSprite();  // forgets camPixels (it does not own it)
  if (camPixels) {
    heap_caps_free(camPixels);
    camPixels = nullptr;
  }
  ledcDetach(CAM_XCLK_PIN);
  camRunning = false;
}

// Grabs one frame and shows it. Blocks for at most one frame time (~33 ms).
void cameraShowFrame() {
  ESPVideoBufferClass frame = camCapture.captureBuffer();
  if (!frame.valid()) return;

  ppa_srm_oper_config_t op = {};
  op.in.buffer = frame.data();
  op.in.pic_w = CAM_W;
  op.in.pic_h = CAM_H;
  op.in.block_w = CROP_W;
  op.in.block_h = CROP_H;
  op.in.block_offset_x = (CAM_W - CROP_W) / 2;
  op.in.block_offset_y = (CAM_H - CROP_H) / 2;
  op.in.srm_cm = PPA_SRM_COLOR_MODE_RGB565;
  op.out.buffer = camPixels;
  op.out.buffer_size = camPixelsSize;
  op.out.pic_w = PREVIEW_W;
  op.out.pic_h = PREVIEW_H;
  op.out.srm_cm = PPA_SRM_COLOR_MODE_RGB565;
  op.rotation_angle = PPA_SRM_ROTATION_ANGLE_0;
  op.scale_x = CAM_SCALE;
  op.scale_y = CAM_SCALE;
  op.mirror_x = CAM_MIRROR_X;
  op.mirror_y = CAM_MIRROR_Y;
  // M5Canvas stores 16-bit pixels big-endian; the ISP gives little-endian.
  // The PPA swaps the two bytes for free while it copies.
  op.byte_swap = true;
  op.mode = PPA_TRANS_MODE_BLOCKING;
  if (ppa_do_scale_rotate_mirror(camPpa, &op) != ESP_OK) return;
  // (frame goes out of scope here and is handed back to the driver)

  drawCamBadge();
  camCanvas.pushSprite(PREVIEW_X, PREVIEW_Y);

  camFrames++;
  if (millis() - camFpsMs >= 5000) {
    Serial.printf("Camera: %.1f fps\n", camFrames * 1000.0f / (millis() - camFpsMs));
    camFrames = 0;
    camFpsMs = millis();
  }
}

// ---------------------------------------------------------------------------
// Screen functions
// ---------------------------------------------------------------------------
void cameraEnter() {
  drawHeader("Camera");
  auto& d = M5.Display;
  // Dark frame with a thin border around the preview area.
  d.fillSmoothRoundRect(PREVIEW_X - 2, PREVIEW_Y - 2, PREVIEW_W + 4, PREVIEW_H + 4, 16, C_BORDER2);
  d.fillRect(PREVIEW_X, PREVIEW_Y, PREVIEW_W, PREVIEW_H, C_DARK);

  camFrozen = false;
  drawCamMessage("Starting camera...", "");
  const char* error = cameraStart();
  if (error) {
    Serial.printf("Camera: failed - %s\n", error);
    cameraStop();
    drawCamMessage("Camera did not start", error);
  }

  drawSnapButton();
  drawButton(camResumeBtn, FONT_LABEL, 16);
  d.setFont(FONT_SMALL);
  d.setTextColor(C_TEXT2);
  d.setTextDatum(middle_center);
  d.drawString("Snap freezes the current frame", 1040, 540);
  d.drawString("on screen. Nothing is saved.", 1040, 568);
}

void cameraLoop() {
  int x, y;
  if (touchPressed(x, y)) {
    if (hit(backBtn, x, y)) { goTo(HOME); return; }
    if (camRunning && hit(camSnapBtn, x, y) && !camFrozen) {
      camFrozen = true;
      drawCamBadge();  // redraw the badge on the frozen frame
      camCanvas.pushSprite(PREVIEW_X, PREVIEW_Y);
    }
    if (camRunning && hit(camResumeBtn, x, y)) camFrozen = false;
  }
  if (camRunning && !camFrozen) cameraShowFrame();
}

void cameraExit() {
  if (camRunning) cameraStop();
}
