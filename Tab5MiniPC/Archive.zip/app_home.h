// app_home.h - the Home screen: status bar + 3 x 2 grid of app tiles.
// Tap the Wi-Fi name to open Wi-Fi, tap the clock to open Date & Time.
//
// The status bar is drawn into an M5Canvas (an off-screen image in PSRAM)
// and then pushed to the display in one go. Redrawing it once per second
// this way never flickers, and nothing else on the screen is touched.
#pragma once
#include <WiFi.h>
#include "ui.h"
#include "clock.h"

// ---------------------------------------------------------------------------
// Status bar
// ---------------------------------------------------------------------------
constexpr int STATUS_H = 64;

M5Canvas statusBar(&M5.Display);  // 1280 x 64 off-screen buffer
Button wifiArea;                  // tappable Wi-Fi icon + name, set when drawn
Button clockArea;                 // tappable clock (opens Date & Time)
uint32_t lastStatusDraw = 0;

void drawStatusBar() {
  auto& s = statusBar;
  s.fillSprite(C_DARK);
  s.drawFastHLine(0, STATUS_H - 1, SCREEN_W, C_BORDER);

  s.setFont(FONT_LABEL);
  s.setTextColor(C_TEXT);
  s.setTextDatum(middle_left);
  s.drawString("TAB5 MINI PC", 32, STATUS_H / 2);

  // Right side is laid out from the right edge towards the left:
  // [wifi icon + name]  32 px  [battery icon + %]  32 px  [clock]
  char clock[16];
  formatClock(clock, sizeof(clock));

  int level = M5.Power.getBatteryLevel();  // 0..100, or negative if unknown
  char batt[16];
  if (level >= 0) snprintf(batt, sizeof(batt), "%d%%", level);
  else snprintf(batt, sizeof(batt), "--%%");

  bool online = (WiFi.status() == WL_CONNECTED);
  String name = online ? WiFi.SSID() : String("No Wi-Fi");
  if (name.length() > 16) name = name.substring(0, 15) + "~";  // keep the bar tidy

  s.setFont(FONT_MONO);
  int cy = STATUS_H / 2;
  int x = SCREEN_W - 32;

  s.setTextDatum(middle_right);
  s.drawString(clock, x, cy);
  int clockLeft = x - s.textWidth(clock);
  clockArea = {clockLeft - 16, 0, SCREEN_W - clockLeft + 16, STATUS_H, "", C_DARK, C_TEXT};
  x -= s.textWidth(clock) + 32;

  s.drawString(batt, x, cy);
  x -= s.textWidth(batt) + 10 + 28;

  // Draw the icons onto the canvas instead of the display.
  iconDrawOn(s);
  iconBattery(x, cy - 14, 28, max(level, 0), C_TEXT, C_DARK);
  x -= 32;

  s.setTextColor(online ? C_TEXT : C_TEXT2);
  s.drawString(name, x, cy);
  int iconX = x - s.textWidth(name) - 10 - 26;
  iconWifi(iconX, cy - 13, 26, 2.2f, online ? C_BLUE : C_TEXT2, C_DARK);
  iconDrawOn(M5.Display);

  // The whole "icon + name" block is the tap target for opening Wi-Fi.
  wifiArea = {iconX - 8, 0, (x - iconX) + 16, STATUS_H, "", C_DARK, C_TEXT};

  s.pushSprite(0, 0);
  lastStatusDraw = millis();
}

// ---------------------------------------------------------------------------
// Tiles
// ---------------------------------------------------------------------------
struct Tile {
  Screen target;
  const char* title;
  void (*icon)(int x, int y, int size, uint16_t fg, uint16_t bg);
  uint16_t iconColor;
};

void iconWifiTile(int x, int y, int size, uint16_t fg, uint16_t bg) { iconWifi(x, y, size, 1.6f, fg, bg); }

const Tile tiles[6] = {
  {CAMERA,   "Camera",         iconCamera,   C_AMBER},
  {RECORDER, "Recorder",       iconMic,      C_AMBER},
  {MICMETER, "Mic Meter",      iconBars,     C_AMBER},
  {SPEAKER,  "Speaker",        iconSpeaker,  C_AMBER},
  {RADIO,    "Internet Radio", iconRadio,    C_AMBER},
  {WIFI,     "Wi-Fi",          iconWifiTile, C_BLUE},
};

// Grid layout, matching the mockup: 40 px side padding, 36 px top,
// 40 px bottom, 28 px gaps between tiles.
constexpr int GRID_X = 40, GRID_TOP = STATUS_H + 36, GRID_GAP = 28;
constexpr int TILE_W = (SCREEN_W - 2 * 40 - 2 * GRID_GAP) / 3;                // 381
constexpr int TILE_H = (SCREEN_H - GRID_TOP - 40 - GRID_GAP) / 2;             // 276

Button tileRect(int i) {
  int col = i % 3, row = i / 3;
  return {GRID_X + col * (TILE_W + GRID_GAP), GRID_TOP + row * (TILE_H + GRID_GAP), TILE_W, TILE_H,
          tiles[i].title, C_PANEL, C_TEXT};
}

void drawTile(int i) {
  auto& d = M5.Display;
  Button r = tileRect(i);
  d.fillSmoothRoundRect(r.x, r.y, r.w, r.h, R_TILE, C_BORDER);
  d.fillSmoothRoundRect(r.x + 1, r.y + 1, r.w - 2, r.h - 2, R_TILE - 1, C_PANEL);

  // Icon (76 px) and title stacked and centred in the tile.
  int cx = r.x + r.w / 2;
  int top = r.y + (r.h - 76 - 16 - 30) / 2;
  tiles[i].icon(cx - 38, top, 76, tiles[i].iconColor, C_PANEL);

  d.setTextDatum(top_center);
  d.setFont(FONT_TITLE);
  d.setTextColor(C_TEXT);
  d.drawString(tiles[i].title, cx, top + 76 + 16);
}

// ---------------------------------------------------------------------------
// Screen functions
// ---------------------------------------------------------------------------
void homeEnter() {
  M5.Display.fillScreen(C_BG);
  if (statusBar.width() == 0) {
    statusBar.setPsram(true);  // keep the 160 KB buffer out of internal RAM
    statusBar.createSprite(SCREEN_W, STATUS_H);
  }
  drawStatusBar();
  for (int i = 0; i < 6; i++) drawTile(i);
}

void homeLoop() {
  // Refresh only the status bar, once per second (clock, battery, Wi-Fi).
  if (millis() - lastStatusDraw >= 1000) drawStatusBar();

  int x, y;
  if (!touchPressed(x, y)) return;

  if (hit(wifiArea, x, y)) {
    goTo(WIFI);
    return;
  }
  if (hit(clockArea, x, y)) {
    goTo(DATETIME);
    return;
  }
  for (int i = 0; i < 6; i++) {
    if (hit(tileRect(i), x, y)) {
      goTo(tiles[i].target);
      return;
    }
  }
}

void homeExit() {
  // Nothing to release: Home uses no hardware. The status bar canvas is kept
  // for the next visit.
}
