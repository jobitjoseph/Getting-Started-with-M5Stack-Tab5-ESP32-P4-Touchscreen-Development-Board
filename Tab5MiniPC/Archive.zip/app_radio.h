// app_radio.h - internet radio with three presets and your own stream URLs.
//
// HOW THE SOUND GETS TO THE SPEAKER
// ESP32-audioI2S (by schreibfaul1) downloads and decodes the MP3 stream in
// its own background task. Normally it sends the sound to an I2S amplifier
// by itself. On the Tab5 the speaker path (ES8388 codec + amp) is managed
// by M5Unified, so instead we:
//   1. give the library a spare I2S port (I2S_NUM_1). Its DMA clock paces the
//      decoding in real time, but it never actually drives the speaker pins
//      (see radioCreatePlayer() for why);
//   2. catch every decoded block in audio_process_i2s(), convert it to
//      16-bit stereo and queue it on M5.Speaker with playRaw().
// That way the codec, the amplifier and the volume stay in M5Unified's
// hands, exactly like in the Speaker and Recorder apps.
//
// Library note: this needs ESP32-audioI2S 4.x. Other installed libraries
// may also contain a file called Audio.h (for example Adafruit's "Audio"
// library). Including a file that ONLY ESP32-audioI2S has first makes the
// Arduino IDE pick the right library for Audio.h too.
#pragma once
#include <audiolib_structs.hpp>  // only in ESP32-audioI2S: selects that library
#include <Audio.h>
#include <WiFi.h>
#include "ui.h"
#include "audio_app.h"

// ---------------------------------------------------------------------------
// Stations (kept in RAM only)
// ---------------------------------------------------------------------------
struct Station {
  String name;
  String url;
  bool addedByUser;
};

constexpr int PRESET_COUNT = 3;
constexpr int MAX_USER_STATIONS = 5;
constexpr int MAX_STATIONS = PRESET_COUNT + MAX_USER_STATIONS;
Station stations[MAX_STATIONS] = {
  {"SomaFM Groove Salad", "http://ice1.somafm.com/groovesalad-128-mp3", false},
  {"SomaFM Drone Zone", "http://ice2.somafm.com/dronezone-128-mp3", false},
  {"Radio Paradise", "http://stream.radioparadise.com/mp3-128", false},
};
int stationCount = PRESET_COUNT;
int radioSelected = 0;
int radioScroll = 0;

// Adds a station from the Add Stream screen. Returns nullptr if it worked,
// otherwise a message for the user.
const char* radioAddStation(const String& name, const String& url) {
  if (stationCount >= MAX_STATIONS) return "List is full (5 of your own stations)";
  stations[stationCount] = {name, url, true};
  radioSelected = stationCount++;
  return nullptr;
}

// ---------------------------------------------------------------------------
// Player
// ---------------------------------------------------------------------------
Audio* radioPlayer = nullptr;
enum RadioState { RADIO_STOPPED, RADIO_CONNECTING, RADIO_PLAYING, RADIO_ERROR };
RadioState radioState = RADIO_STOPPED;
String radioError;
uint32_t radioStartMs = 0;

// Buffers handed to M5.Speaker. It keeps a pointer to each buffer until that
// buffer has been played, and holds at most two per channel, so three
// buffers used in turn are always enough.
constexpr int RADIO_CHANNEL = 0;                // M5.Speaker virtual channel
constexpr size_t RADIO_BUF_SAMPLES = 4096;      // 2048 stereo frames (~46 ms)
int16_t* radioBuf[3] = {nullptr, nullptr, nullptr};
int radioBufIndex = 0;
size_t radioBufFill = 0;
volatile bool radioOutputOn = false;            // set false to drop audio while stopping
volatile bool radioGotAudio = false;            // first sound arrived

// Called by ESP32-audioI2S (from its own task) with every decoded block:
// 'words' int32 values, interleaved left/right, each a 16-bit sample shifted
// up by 16 bits.
void audio_process_i2s(int32_t* samples, int16_t words, bool* continueI2S) {
  *continueI2S = false;  // do not send it to the library's own I2S port
  if (!radioOutputOn || !radioPlayer) return;

  uint32_t rate = radioPlayer->getSampleRate();
  for (int i = 0; i < words; i++) {
    radioBuf[radioBufIndex][radioBufFill++] = (int16_t)(samples[i] >> 16);
    if (radioBufFill < RADIO_BUF_SAMPLES) continue;

    // Buffer full: wait while M5.Speaker already has two queued. Waiting
    // here is fine (we are in the library's task, not in loop()), and it
    // keeps the decoder in step with the speaker.
    uint32_t t0 = millis();
    while (radioOutputOn && M5.Speaker.isPlaying(RADIO_CHANNEL) >= 2 && millis() - t0 < 300) vTaskDelay(1);
    if (!radioOutputOn) return;
    M5.Speaker.playRaw(radioBuf[radioBufIndex], RADIO_BUF_SAMPLES, rate, true, 1, RADIO_CHANNEL);
    radioBufIndex = (radioBufIndex + 1) % 3;
    radioBufFill = 0;
    radioGotAudio = true;
  }
}

// Creates the player once and keeps it (the library is not meant to be
// created and destroyed repeatedly).
//
// Why pass the real speaker pins to setPinout()? The library only starts its
// decoder if setPinout() succeeds, and that needs valid pin numbers. So we
// call it BEFORE M5.Speaker.begin(): M5.Speaker then takes the pins back for
// I2S port 0 (on the ESP32 the last peripheral connected to a pin wins).
// The library's port 1 keeps running with no pins attached, which is exactly
// what we want: its timing paces the decoder, M5.Speaker makes the sound.
bool radioCreatePlayer() {
  if (radioPlayer) return true;
  for (int i = 0; i < 3; i++) {
    radioBuf[i] = (int16_t*)heap_caps_malloc(RADIO_BUF_SAMPLES * sizeof(int16_t), MALLOC_CAP_SPIRAM);
    if (!radioBuf[i]) return false;
  }
  audioRelease();  // make sure M5.Speaker is not running while we set up
  radioPlayer = new Audio(I2S_NUM_1);
  // Tab5 speaker pins: BCLK 27, WS 29, DOUT 26, MCLK 30
  if (!radioPlayer->setPinout(27, 29, 26, 30)) return false;
  radioPlayer->setVolume(21);                 // library at full level; M5.Speaker sets the volume
  radioPlayer->setConnectionTimeout(4000, 6000);
  Audio::audio_info_callback = [](Audio::msg_t m) {
    if (m.e != Audio::evt_vu && m.e != Audio::evt_spectrum && m.msg) {
      Serial.printf("Radio %s: %s\n", Audio::eventStr[m.e], m.msg);
    }
  };
  return true;
}

// Stops the stream (called from audioRelease() and the Stop button).
void radioStopStream() {
  radioOutputOn = false;
  if (radioPlayer && radioPlayer->isRunning()) radioPlayer->stopSong();
  M5.Speaker.stop(RADIO_CHANNEL);
  radioState = RADIO_STOPPED;
}

// ---------------------------------------------------------------------------
// Layout
// ---------------------------------------------------------------------------
constexpr int RL_X = 32, RL_W = 520, RL_ROWS_Y = 150, RL_ROW_H = 66, RL_ROW_GAP = 8, RL_VISIBLE = 6;
Button radioAddBtn = {RL_X, 604, RL_W, 66, "+ Add stream URL", C_BG, C_BLUE};
Button radioAddBtnShort = {RL_X, 604, 360, 66, "+ Add stream URL", C_BG, C_BLUE};
Button radioUpBtn = {RL_X + 368, 604, 72, 66, "", C_PANEL, C_TEXT};
Button radioDownBtn = {RL_X + 448, 604, 72, 66, "", C_PANEL, C_TEXT};

constexpr int CARD_X = 584, CARD_Y = 116, CARD_W = 664, CARD_H = 576, CARD_PAD = 40;
Button radioPlayBtn = {CARD_X + CARD_PAD, 330, 200, 92, "Play", C_AMBER, C_BG};
Button radioStopBtn = {CARD_X + CARD_PAD + 220, 330, 200, 92, "Stop", C_BG, C_TEXT};
Button radioWifiBtn = {CARD_X + CARD_PAD, 330, 300, 92, "Open Wi-Fi", C_BLUE, C_BG};
const VolumeRow radioVolume = {CARD_X + CARD_PAD, 470, CARD_W - 2 * CARD_PAD, 72, C_PANEL};

bool radioOnlineShown = false;   // what the card currently shows
uint32_t radioLastCheckMs = 0;

bool radioNeedsScroll() { return stationCount > RL_VISIBLE; }

Button radioRowRect(int row) {
  return {RL_X, RL_ROWS_Y + row * (RL_ROW_H + RL_ROW_GAP), RL_W, RL_ROW_H, "", C_PANEL, C_TEXT};
}

// ---------------------------------------------------------------------------
// Drawing
// ---------------------------------------------------------------------------
void drawStationList() {
  auto& d = M5.Display;
  d.fillRect(RL_X, RL_ROWS_Y, RL_W, SCREEN_H - RL_ROWS_Y, C_BG);
  for (int row = 0; row < RL_VISIBLE; row++) {
    int i = radioScroll + row;
    if (i >= stationCount) break;
    Button r = radioRowRect(row);
    bool sel = (i == radioSelected);
    int b = sel ? 3 : 1;
    d.fillSmoothRoundRect(r.x, r.y, r.w, r.h, R_SMALL, sel ? C_AMBER : C_BORDER);
    d.fillSmoothRoundRect(r.x + b, r.y + b, r.w - 2 * b, r.h - 2 * b, R_SMALL - b, C_PANEL);
    d.setTextDatum(middle_left);
    d.setTextColor(C_TEXT);
    d.drawString(fitText(stations[i].name, FONT_LABEL, r.w - 44), r.x + 22, r.y + 23);
    d.setFont(&fonts::FreeSans9pt7b);
    d.setTextColor(stations[i].addedByUser ? C_BLUE : C_TEXT2);
    d.drawString(stations[i].addedByUser ? "Added by you" : "Preset", r.x + 22, r.y + 49);
  }

  // "+ Add stream URL" with a dashed outline, and scroll arrows if needed.
  const Button& add = radioNeedsScroll() ? radioAddBtnShort : radioAddBtn;
  for (int x = add.x; x < add.x + add.w - 10; x += 16) {
    d.fillRect(x, add.y, 10, 2, C_BORDER2);
    d.fillRect(x, add.y + add.h - 2, 10, 2, C_BORDER2);
  }
  for (int y = add.y; y < add.y + add.h - 6; y += 12) {
    d.fillRect(add.x, y, 2, 6, C_BORDER2);
    d.fillRect(add.x + add.w - 2, y, 2, 6, C_BORDER2);
  }
  d.setFont(FONT_LABEL);
  d.setTextColor(C_BLUE);
  d.setTextDatum(middle_center);
  d.drawString(add.label, add.x + add.w / 2, add.y + add.h / 2);

  if (radioNeedsScroll()) {
    for (int k = 0; k < 2; k++) {
      const Button& b = k ? radioDownBtn : radioUpBtn;
      drawButton(b, FONT_LABEL, R_SMALL);
      int cx = b.x + b.w / 2, cy = b.y + b.h / 2;
      if (k == 0) d.fillTriangle(cx - 14, cy + 8, cx + 14, cy + 8, cx, cy - 10, C_TEXT);
      else d.fillTriangle(cx - 14, cy - 8, cx + 14, cy - 8, cx, cy + 10, C_TEXT);
    }
  }
}

void drawRadioStatus() {
  auto& d = M5.Display;
  int y = 258, x = CARD_X + CARD_PAD;
  d.fillRect(x, y - 18, CARD_W - 2 * CARD_PAD, 36, C_PANEL);
  String text;
  uint16_t dot = C_TEXT2;
  switch (radioState) {
    case RADIO_STOPPED:    text = "Stopped"; break;
    case RADIO_CONNECTING: text = "Connecting..."; dot = C_AMBER; break;
    case RADIO_PLAYING:
      text = String("Playing - ") + (radioPlayer ? radioPlayer->getCodecname() : "MP3") + " stream";
      dot = C_BLUE;
      break;
    case RADIO_ERROR:      text = "Error: " + radioError; dot = C_AMBER; break;
  }
  d.fillSmoothCircle(x + 6, y, 6, dot);
  d.setFont(FONT_MONO);
  d.setTextColor(C_TEXT2);
  d.setTextDatum(middle_left);
  d.drawString(fitText(text, FONT_MONO, CARD_W - 2 * CARD_PAD - 22), x + 22, y);
}

void drawNowPlayingCard() {
  auto& d = M5.Display;
  d.fillSmoothRoundRect(CARD_X, CARD_Y, CARD_W, CARD_H, R_BTN, C_PANEL);
  int x = CARD_X + CARD_PAD;
  d.setTextDatum(middle_left);
  d.setFont(FONT_LABEL);
  d.setTextColor(C_TEXT2);
  d.drawString("NOW PLAYING", x, 170);

  radioOnlineShown = (WiFi.status() == WL_CONNECTED);
  if (!radioOnlineShown) {
    d.setFont(FONT_TITLE);
    d.setTextColor(C_TEXT);
    d.drawString("Connect to Wi-Fi first", x, 214);
    d.setFont(FONT_SMALL);
    d.setTextColor(C_TEXT2);
    d.drawString("The radio streams over the internet.", x, 258);
    drawButton(radioWifiBtn, FONT_TITLE);
    return;
  }

  d.setFont(FONT_TITLE);
  d.setTextColor(C_TEXT);
  d.drawString(fitText(stations[radioSelected].name, FONT_TITLE, CARD_W - 2 * CARD_PAD), x, 214);
  drawRadioStatus();
  drawButton(radioPlayBtn, FONT_TITLE, R_BTN, BI_PLAY, C_BG);
  drawButton(radioStopBtn, FONT_TITLE, R_BTN, BI_SQUARE, C_TEXT);
  volumeRowDraw(radioVolume);
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------
void radioPlay() {
  if (WiFi.status() != WL_CONNECTED) return;
  if (!radioCreatePlayer()) {
    radioState = RADIO_ERROR;
    radioError = "audio player did not start";
    drawRadioStatus();
    return;
  }
  radioStopStream();
  if (!audioStartSpeaker(AUDIO_RADIO)) {
    radioState = RADIO_ERROR;
    radioError = "speaker did not start";
    drawRadioStatus();
    return;
  }
  radioBufFill = 0;
  radioBufIndex = 0;
  radioGotAudio = false;
  radioOutputOn = true;
  radioState = RADIO_CONNECTING;
  drawRadioStatus();

  // connecttohost() opens the connection (a second or two; the screen
  // waits meanwhile). The download and decoding then run in the background.
  radioStartMs = millis();
  if (!radioPlayer->connecttohost(stations[radioSelected].url.c_str())) {
    radioOutputOn = false;
    radioState = RADIO_ERROR;
    radioError = "could not connect";
    drawRadioStatus();
  }
}

void radioStopPressed() {
  if (audioApp == AUDIO_RADIO) audioRelease();  // stops the stream and the speaker
  radioState = RADIO_STOPPED;
  drawRadioStatus();
}

// ---------------------------------------------------------------------------
// Screen functions
// ---------------------------------------------------------------------------
void radioEnter() {
  drawHeader("Internet Radio");
  auto& d = M5.Display;
  d.setFont(FONT_LABEL);
  d.setTextColor(C_TEXT2);
  d.setTextDatum(middle_left);
  d.drawString("STATIONS", RL_X, 132);
  if (radioSelected >= radioScroll + RL_VISIBLE) radioScroll = radioSelected - RL_VISIBLE + 1;
  radioState = RADIO_STOPPED;
  drawStationList();
  drawNowPlayingCard();
}

void radioLoop() {
  // Keep the stream flowing: the library reads the network in loop().
  if (radioPlayer && audioApp == AUDIO_RADIO) radioPlayer->loop();

  // Status changes
  if (radioState == RADIO_CONNECTING && radioGotAudio) {
    radioState = RADIO_PLAYING;
    drawRadioStatus();
  } else if (radioState == RADIO_CONNECTING && millis() - radioStartMs > 15000) {
    radioError = "no audio received";
    audioRelease();
    radioState = RADIO_ERROR;
    drawRadioStatus();
  } else if (radioState == RADIO_PLAYING && !radioPlayer->isRunning()) {
    radioError = "stream ended";
    audioRelease();
    radioState = RADIO_ERROR;
    drawRadioStatus();
  }

  // Wi-Fi came or went: redraw the card once a second if it changed.
  if (millis() - radioLastCheckMs > 1000) {
    radioLastCheckMs = millis();
    if ((WiFi.status() == WL_CONNECTED) != radioOnlineShown) {
      if (audioApp == AUDIO_RADIO) audioRelease();
      radioState = RADIO_STOPPED;
      drawNowPlayingCard();
    }
  }

  if (radioOnlineShown) volumeRowUpdate(radioVolume);

  int x, y;
  if (!touchPressed(x, y)) return;
  if (hit(backBtn, x, y)) { goTo(HOME); return; }

  const Button& add = radioNeedsScroll() ? radioAddBtnShort : radioAddBtn;
  if (hit(add, x, y)) { goTo(ADDSTREAM); return; }
  if (radioNeedsScroll() && hit(radioUpBtn, x, y) && radioScroll > 0) {
    radioScroll--;
    drawStationList();
    return;
  }
  if (radioNeedsScroll() && hit(radioDownBtn, x, y) && radioScroll + RL_VISIBLE < stationCount) {
    radioScroll++;
    drawStationList();
    return;
  }
  for (int row = 0; row < RL_VISIBLE; row++) {
    int i = radioScroll + row;
    if (i < stationCount && hit(radioRowRect(row), x, y)) {
      bool wasPlaying = (radioState == RADIO_CONNECTING || radioState == RADIO_PLAYING);
      radioSelected = i;
      drawStationList();
      drawNowPlayingCard();
      if (wasPlaying) radioPlay();  // switch stations while playing
      return;
    }
  }

  if (!radioOnlineShown) {
    if (hit(radioWifiBtn, x, y)) goTo(WIFI);
    return;
  }
  if (hit(radioPlayBtn, x, y)) radioPlay();
  if (hit(radioStopBtn, x, y)) radioStopPressed();
}

void radioExit() {
  audioRelease();  // stops the stream if it is playing
}
