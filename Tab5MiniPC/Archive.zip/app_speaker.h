// app_speaker.h - plays a built-in melody with M5.Speaker.tone().
//
// The melody is a table of notes (frequency + length). Instead of playing it
// with delay() (which would freeze the touch screen), loop() checks the time
// and starts the next note when the current one is over.
#pragma once
#include "ui.h"
#include "audio_app.h"

struct Note {
  uint16_t freq;  // Hz
  uint16_t ms;    // length
};

// "Twinkle, Twinkle, Little Star", first line (14 notes), one octave above
// middle C so it sounds clear on the small speaker.
const Note melody[] = {
  {523, 400}, {523, 400}, {784, 400}, {784, 400}, {880, 400}, {880, 400}, {784, 800},  // C C G G A A G
  {698, 400}, {698, 400}, {659, 400}, {659, 400}, {587, 400}, {587, 400}, {523, 800},  // F F E E D D C
};
const int MELODY_LEN = sizeof(melody) / sizeof(melody[0]);

bool melodyPlaying = false;
int melodyIndex = 0;        // note currently playing
uint32_t noteStartMs = 0;

// Layout (vertically centred in the area under the header)
Button spkPlayBtn = {386, 406, 240, 100, "Play", C_AMBER, C_BG};
Button spkStopBtn = {654, 406, 240, 100, "Stop", C_PANEL, C_TEXT};
const VolumeRow spkVolume = {200, 542, 880, 80, C_BG};
constexpr int SPK_PROGRESS_Y = 360;

void speakerDrawProgress() {
  char buf[32];
  if (melodyPlaying) snprintf(buf, sizeof(buf), "note %d of %d", melodyIndex + 1, MELODY_LEN);
  else snprintf(buf, sizeof(buf), "%d notes - tap Play", MELODY_LEN);
  drawTextBox(340, SPK_PROGRESS_Y - 16, 600, 32, buf, FONT_MONO, C_TEXT2, C_BG, middle_center);
}

void speakerPlayNote(int i) {
  melodyIndex = i;
  noteStartMs = millis();
  // Slightly shorter than the note slot, so repeated notes are heard as two.
  M5.Speaker.tone(melody[i].freq, melody[i].ms - 40);
  speakerDrawProgress();
}

void speakerStop() {
  melodyPlaying = false;
  M5.Speaker.stop();
  speakerDrawProgress();
}

void speakerEnter() {
  drawHeader("Speaker");
  auto& d = M5.Display;
  iconMusicNote(SCREEN_W / 2 - 36, 187, 72, C_AMBER, C_BG);
  d.setTextDatum(top_center);
  d.setFont(FONT_TITLE);
  d.setTextColor(C_TEXT);
  d.drawString("Built-in melody", SCREEN_W / 2, 270);
  d.setFont(FONT_SMALL);
  d.setTextColor(C_TEXT2);
  d.drawString("Twinkle, Twinkle, Little Star", SCREEN_W / 2, 312);

  melodyPlaying = false;
  speakerDrawProgress();
  drawButton(spkPlayBtn, FONT_TITLE, R_BTN, BI_PLAY, C_BG);
  drawButton(spkStopBtn, FONT_TITLE, R_BTN, BI_SQUARE, C_TEXT);
  volumeRowDraw(spkVolume);
}

void speakerLoop() {
  volumeRowUpdate(spkVolume);

  int x, y;
  if (touchPressed(x, y)) {
    if (hit(backBtn, x, y)) { goTo(HOME); return; }
    if (hit(spkPlayBtn, x, y) && audioStartSpeaker()) {
      melodyPlaying = true;
      speakerPlayNote(0);  // Play always starts from the first note
    }
    if (hit(spkStopBtn, x, y)) speakerStop();
  }

  // Step through the melody without blocking.
  if (melodyPlaying && millis() - noteStartMs >= melody[melodyIndex].ms) {
    if (melodyIndex + 1 < MELODY_LEN) speakerPlayNote(melodyIndex + 1);
    else speakerStop();
  }
}

void speakerExit() {
  melodyPlaying = false;
  audioRelease();
}
