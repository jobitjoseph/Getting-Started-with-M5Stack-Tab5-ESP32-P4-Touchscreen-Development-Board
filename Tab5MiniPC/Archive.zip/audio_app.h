// audio_app.h - which app is using the audio hardware, the shared volume, and the volume
// row widget (- button, slider, + button, percentage).
//
// THE ONE-AUDIO-APP RULE
// On the Tab5 the two microphones (ES7210) and the speaker (ES8388 + amp)
// share one I2S bus (I2S port 0, same clock pins). M5Unified can drive the
// bus as a microphone OR as a speaker, never both at once. The internet radio
// also plays through M5.Speaker. So at any moment exactly one of these uses
// the audio hardware:
//     nobody  |  Mic  |  Speaker  |  Radio
// Before an app starts its audio it calls audioStartMic() or
// audioStartSpeaker(). Both first call audioRelease(), which cleanly stops
// whoever had the hardware before. Every app's Exit() calls audioRelease().
//
// (This file is not called audio.h on purpose: Windows and macOS ignore
// upper/lower case in file names, so the radio library's <Audio.h> would
// find our file instead of its own.)
#pragma once
#include "ui.h"

enum AudioApp { AUDIO_NONE, AUDIO_MIC, AUDIO_SPEAKER, AUDIO_RADIO };
AudioApp audioApp = AUDIO_NONE;  // the app currently using the mic/speaker

void radioStopStream();  // defined in app_radio.h

// ---------------------------------------------------------------------------
// Volume: one setting shared by every screen that makes sound
// ---------------------------------------------------------------------------
int volumePercent = 60;

// M5.Speaker's master volume goes from 0 to 255.
void applyVolume() {
  M5.Speaker.setVolume(volumePercent * 255 / 100);
}

// ---------------------------------------------------------------------------
// Starting and stopping audio
// ---------------------------------------------------------------------------
void audioRelease() {
  switch (audioApp) {
    case AUDIO_MIC:
      M5.Mic.end();  // stops recording and frees the I2S bus
      break;
    case AUDIO_RADIO:
      radioStopStream();  // stop downloading/decoding first...
      [[fallthrough]];    // ...then stop the speaker as well
    case AUDIO_SPEAKER:
      M5.Speaker.stop();
      M5.Speaker.end();  // mutes the amp and frees the I2S bus
      break;
    case AUDIO_NONE:
      break;
  }
  audioApp = AUDIO_NONE;
}

bool audioStartMic() {
  if (audioApp == AUDIO_MIC) return true;
  audioRelease();
  if (!M5.Mic.begin()) return false;
  audioApp = AUDIO_MIC;
  return true;
}

// who = AUDIO_SPEAKER for sounds made by the sketch, AUDIO_RADIO for the radio.
bool audioStartSpeaker(AudioApp who = AUDIO_SPEAKER) {
  if (audioApp == who) return true;
  audioRelease();
  if (!M5.Speaker.begin()) return false;
  applyVolume();
  audioApp = who;
  return true;
}

// ---------------------------------------------------------------------------
// Volume row widget
// ---------------------------------------------------------------------------
// Layout (left to right): [-]  "Volume" + slider  [+]  "70%"
// x, y, w give the whole row; btn is the size of the square - and + buttons;
// bg is the colour behind the row (screen or card).
struct VolumeRow {
  int x, y, w, btn;
  uint16_t bg;
};

constexpr int VOL_PCT_W = 100;  // width of the "70%" text
constexpr int VOL_GAP = 20;

Button volMinusBtn(const VolumeRow& r) { return {r.x, r.y, r.btn, r.btn, "-", r.bg, C_TEXT}; }
Button volPlusBtn(const VolumeRow& r) {
  return {r.x + r.w - VOL_PCT_W - VOL_GAP - r.btn, r.y, r.btn, r.btn, "+", r.bg, C_TEXT};
}
int volSliderX(const VolumeRow& r) { return r.x + r.btn + VOL_GAP; }
int volSliderW(const VolumeRow& r) { return r.w - 2 * r.btn - 3 * VOL_GAP - VOL_PCT_W; }

M5Canvas volCanvas(&M5.Display);  // off-screen image for the slider (no flicker while dragging)

// Redraws only the slider and the percentage (used while the volume changes).
void volumeRowDrawValue(const VolumeRow& r) {
  int sw = volSliderW(r), sh = 40;
  if (volCanvas.width() != sw) {
    volCanvas.deleteSprite();
    volCanvas.setPsram(true);
    volCanvas.createSprite(sw, sh);
  }
  // Track, blue filled part, and a round knob. The knob travels between
  // its radius and (width - radius) so it never gets cut off.
  int knobR = 16, trackH = 10;
  int kx = knobR + (sw - 2 * knobR) * volumePercent / 100;
  volCanvas.fillSprite(r.bg);
  volCanvas.fillSmoothRoundRect(0, (sh - trackH) / 2, sw, trackH, trackH / 2, C_BORDER2);
  volCanvas.fillSmoothRoundRect(0, (sh - trackH) / 2, kx, trackH, trackH / 2, C_BLUE);
  volCanvas.fillSmoothCircle(kx, sh / 2, knobR, C_BLUE);
  volCanvas.fillSmoothCircle(kx, sh / 2, knobR - 5, C_TEXT);
  volCanvas.pushSprite(volSliderX(r), r.y + r.btn - sh);

  char pct[8];
  snprintf(pct, sizeof(pct), "%d%%", volumePercent);
  drawTextBox(r.x + r.w - VOL_PCT_W, r.y, VOL_PCT_W, r.btn, pct, &fonts::FreeMonoBold18pt7b, C_TEXT, r.bg,
              middle_right);
}

void volumeRowDraw(const VolumeRow& r) {
  drawButton(volMinusBtn(r), FONT_TITLE, 16);
  drawButton(volPlusBtn(r), FONT_TITLE, 16);
  auto& d = M5.Display;
  d.setFont(FONT_SMALL);
  d.setTextColor(C_TEXT2);
  d.setTextDatum(top_left);
  d.drawString("Volume", volSliderX(r), r.y);
  volumeRowDrawValue(r);
}

// Call every loop. Handles taps on - / + (10 % steps) and dragging the
// slider. Returns true when the volume changed.
bool volumeRowUpdate(const VolumeRow& r) {
  auto t = M5.Touch.getDetail();
  int old = volumePercent;

  if (t.wasPressed()) {
    if (hit(volMinusBtn(r), t.x, t.y)) volumePercent = max(0, volumePercent - 10);
    if (hit(volPlusBtn(r), t.x, t.y)) volumePercent = min(100, volumePercent + 10);
  }

  // Dragging: only if the finger went down on the slider (base_x/base_y is
  // where the touch started), so a swipe elsewhere never moves the volume.
  int sx = volSliderX(r), sw = volSliderW(r);
  bool startedOnSlider = t.base_x >= sx - 20 && t.base_x < sx + sw + 20 &&
                         t.base_y >= r.y && t.base_y < r.y + r.btn;
  if (t.isPressed() && startedOnSlider) {
    volumePercent = constrain((t.x - sx - 16) * 100 / (sw - 32), 0, 100);
  }

  if (volumePercent == old) return false;
  applyVolume();
  volumeRowDrawValue(r);
  return true;
}
